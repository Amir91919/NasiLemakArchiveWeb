<!--
/* Java Script File Last Update : 06 February 2023
Project: batiqa.com (BATIQA Hotels)
Website Designed & Coded by: Aditama (pandavamedia.net)
*/
if (document.location.host=="localhost" || document.location.host=="192.168.0.105" || document.location.host=="192.168.1.105" || document.location.host=="172.20.10.2") {
	var global_site_name = "http://"+document.location.host+"/batiqa.com/";
} else if (document.location.host=="www.pandavamedia.net" || document.location.host=="pandavamedia.net" || document.location.host=="www.pandavamail.com" || document.location.host=="pandavamail.com") {
	var global_site_name = "http://"+document.location.host+"/demo/batiqa.com/";
} else {
	var global_site_name = "https://"+document.location.host+"/";
}
var monthNames = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var BASKET_COOKIE_NAME="bsk-pdv250917";
var REGISTRATION_COOKIE_NAME="pdv-pdv250917";
var EXISTINGCARD_COOKIE_NAME="exst-pdv250917";
var MEMBER_COOKIE_ID="mbr-pdv250917";

//ajax to display photo...
//Create a boolean variable to check for a valid Internet Explorer instance.
var xmlhttp = false;
//Check if we are using IE.
try {
	//If the Javascript version is greater than 5.
	xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
} catch (e) {
	//If not, then use the older active x object.
	try {
		//If we are using Internet Explorer.
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	} catch (E) {
		//Else we must be using a non-IE browser.
		xmlhttp = false;
	}
}
//If we are using a non-IE browser, create a javascript instance of the object.
if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
	xmlhttp = new XMLHttpRequest();
}

//check ipad device
if((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i)) || (navigator.userAgent.match(/iPad/i))){
    var isTouchScreen = 1;
}else{
    var isTouchScreen = 0;
}

String.prototype.trim = function()
{
  return( this.replace(/^\s*([\s\S]*\S+)\s*$|^\s*$/,'$1') );   
}

function ReinitializeAddThis(){
	if (window.addthis){
	
	window.addthis.ost = 0;
	window.addthis.ready();
	}
}

function del_cookie(c_name) {
	document.cookie = c_name + '=; expires=Thu, 01-Jan-70 00:00:01 GMT;';
} 


function setCookie(c_name,value,expiredays) {
	var exdate=new Date();
	exdate.setDate(exdate.getDate()+expiredays);
	document.cookie=c_name+ "=" +escape(value)+
	((expiredays==null) ? "" : ";expires="+exdate.toUTCString()+"; path=/");
}

function getCookie(c_name) {
	if (document.cookie.length>0)
	  {
	  c_start=document.cookie.indexOf(c_name + "=");
	  if (c_start!=-1)
	    {
	    c_start=c_start + c_name.length+1;
	    c_end=document.cookie.indexOf(";",c_start);
	    if (c_end==-1) c_end=document.cookie.length;
	    return unescape(document.cookie.substring(c_start,c_end));
	    }
	  }
	return "";
}

function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=44 && charCode!=46)
        return false;
    return true;
}

function isPhoneKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

function isAlphabetKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode!=8 && charCode!=13) {
	    var charStr = String.fromCharCode(charCode);
	    if (/[a-zA-Z., ]/.test(charStr))
	        return true;
	    return false;
	  }
}

function isUsernameKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode!=8 && charCode!=13) {
	    var charStr = String.fromCharCode(charCode);
	    if (/[a-zA-Z.@_+\- 0-9]/.test(charStr))
	        return true;
	    return false;
	  }
}

function isAlphanumericKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode!=8 && charCode!=13) {
	    var charStr = String.fromCharCode(charCode);
	    if (/[a-zA-Z.,:;()+\- 0-9]/.test(charStr))
	        return true;
	    return false;
	  }
}

function isEmailKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode!=8 && charCode!=13) {
	    var charStr = String.fromCharCode(charCode);
	    if (/[a-zA-Z0-9-_@.]/.test(charStr))
	        return true;
	    return false;
	  }
}

function getRadioCheckedValueToString(radio_name) {
	var returnString = "";
	var fieldobj = document.getElementsByName(radio_name);
  for (var i=0; i < fieldobj.length; i++) {
  	if(fieldobj[i].checked) {
  		if (returnString!="") { returnString = returnString+"|"; }
			returnString = returnString+fieldobj[i].value;
		}	
  }
  return returnString;
} 

function getRadioCheckedValue(radio_name) {
	var fieldobj = document.getElementsByName(radio_name);
  for (var i=0; i < fieldobj.length; i++) {
  	if(fieldobj[i].checked) {
			return fieldobj[i].value;
		}	
  }
} 

function cleanParseVar(toParse) {
	var toReturn="";
	if (toParse!="") {
		toReturn=toParse;
		toReturn=toReturn.replace(/&/g, "|*and*|");
		toReturn=toReturn.replace(/\?/g, "|*ask*|");
		toReturn=toReturn.replace(/�/g, "-");		
		//toReturn=toReturn.replace("&amp;", "|*and*|");
		toReturn=toReturn.replace(/�/g, "'");
		toReturn=toReturn.replace(/’/g, "'");
		//toReturn=toReturn.replace("&nbsp;", " ");
		toReturn=toReturn.replace(/&amp;/gi, "|*and*|");
		toReturn=toReturn.replace(/&nbsp;/gi, " ");
		toReturn=toReturn.replace(/\n/g, "<br>");	
		toReturn=toReturn.replace(/\r/g, "<br>");	
	}
	return toReturn;
}

function convertBreakLine(stringTmp) {
	var toReturn="";
	if (stringTmp!="") {
		toReturn=stringTmp.replace("<br>", "\n");
	}
	return toReturn;
}

function turnOnThis(showWhat) {
  var thediv=document.getElementById(showWhat);
  thediv.style.display = "block";
}

function turnOffThis(showWhat) {
  var thediv=document.getElementById(showWhat);
  thediv.style.display = "none";
} 

function getTodayDate() {
	var currentDate = new Date()
	var day = currentDate.getDate()
	var month = currentDate.getMonth() + 1
	var year = currentDate.getFullYear()
	var dateString = year + "-" + month + "-" + day;
	return dateString;
}

function reWriteDate(strDate,formatStr) {
	var arrMonthName = new Array("","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
	var arr1 = strDate.split('/');
	if (formatStr==1) {
		/* e.g: 23 January 2012 */
		var newDateStr = arr1[0] + " " + arrMonthName[arr1[1]*1] + " " + arr1[2];
	} else if (formatStr==2) {
		/* e.g: 2012-01-23 */
		var newDateStr = arr1[2] + "-" + arr1[1] + "-" + arr1[0];
	}
	return newDateStr;
}

function addSeparatorsNF(nStr, inD, outD, sep) {
	nStr += '';
	var dpos = nStr.indexOf(inD);
	var nStrEnd = '';
	if (dpos != -1) {
		nStrEnd = outD + nStr.substring(dpos + 1, nStr.length);
		nStr = nStr.substring(0, dpos);
	}
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(nStr)) {
		nStr = nStr.replace(rgx, '$1' + sep + '$2');
	}
	return nStr + nStrEnd;
}

function convertPrice(localFormat,numValue) {
	var numStr = numValue
	if (localFormat=="INDONESIA") {
		return addSeparatorsNF(numStr, ',', ',', '.');
	} else {
		return addSeparatorsNF(numStr, '.', '.', ',');
	}
}

function goURL(strURL) {
	document.location.href=strURL;
}

/* utility functions for jquery datepicker */
function nationalDays(date) {
	var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
	//console.log('Checking (raw): ' + m + '-' + d + '-' + y);
	for (i = 0; i < disabledDays.length; i++) {
		if($.inArray((m+1) + '-' + d + '-' + y,disabledDays) != -1 || new Date() > date) {
			//console.log('bad:  ' + (m+1) + '-' + d + '-' + y + ' / ' + disabledDays[i]);
			return [false];
		}
	}
	//console.log('good:  ' + (m+1) + '-' + d + '-' + y);
	return [true];
}
function onlySelectedDays(date) {
	var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
	//console.log('Checking (raw): ' + m + '-' + d + '-' + y);
	for (i = 0; i < selectedDays.length; i++) {
		if($.inArray(y + '-' + ('0' + (m+1)).slice(-2) + '-' + ('0' + d).slice(-2),selectedDays) == -1 || new Date() > date) {
			//console.log('bad:  ' + (m+1) + '-' + d + '-' + y + ' / ' + disabledDays[i]);
			return [false];
		}
	}
	//console.log('good:  ' + (m+1) + '-' + d + '-' + y);
	return [true];
}
function noWeekendsOrHolidays(date) {
	var noWeekend = jQuery.datepicker.noWeekends(date);
	return noWeekend[0] ? nationalDays(date) : noWeekend;
}
function noDaysBesideSelectedDays(date) {
	//var noWeekend = jQuery.datepicker.noWeekends(date);
	//return noWeekend[0] ? nationalDays(date) : noWeekend;
	return onlySelectedDays(date);
}

function removeDiv(EId) {
    return(EObj=document.getElementById(EId))?EObj.parentNode.removeChild(EObj):false;
}

function addSeparatorsNF(nStr, inD, outD, sep) {
	nStr += '';
	var dpos = nStr.indexOf(inD);
	var nStrEnd = '';
	if (dpos != -1) {
		nStrEnd = outD + nStr.substring(dpos + 1, nStr.length);
		nStr = nStr.substring(0, dpos);
	}
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(nStr)) {
		nStr = nStr.replace(rgx, '$1' + sep + '$2');
	}
	return nStr + nStrEnd;
}

Number.prototype.format = function(n, x, s, c) {
    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',
        num = this.toFixed(Math.max(0, ~~n));
    
    return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
};

function convertNumberToPrice(localFormat,strPriceID,numPriceID) {
	var priceNum = document.getElementById(strPriceID).value;
	var priceFormat = convertPrice(localFormat,priceNum);
	//if (priceNum) {
		document.getElementById(strPriceID).value = priceFormat;
		if (localFormat=="INDONESIA") {
			priceNum = priceNum.replace(/[^0-9\,]+/g,"");
		} else {
			priceNum = priceNum.replace(/[^0-9\.]+/g,"");
		}
		//priceNum = priceNum.replace(/[^\d,]+/g,'');
		//priceNum = priceNum.replace(/[^0-9\.]+/g,"");
		//priceNum = priceNum*1;alert(priceNum);
		document.getElementById(numPriceID).value = priceNum;
	//}
	//numbers[i].format(2, 3, '.', ',');
}

function convertPriceToNumber(localFormat,strPriceID) {
	var priceNum = document.getElementById(strPriceID).value;
	if (localFormat=="INDONESIA") {
		priceNum = priceNum.replace(/[^0-9\,]+/g,"");
	} else {
		priceNum = priceNum.replace(/[^0-9\.]+/g,"");
	}
	//priceNum = priceNum.replace(/[^\d,]+/g,'');
	//priceNum = priceNum.replace(/[^0-9\.]+/g,"");
	//priceNum = priceNum*1;
	if (priceNum!="") { document.getElementById(strPriceID).value = priceNum; }
}

/* website specific scripts */
function openLogin(overlayID,boxID) {
	document.getElementById(overlayID).style.display = "block";
	document.getElementById(boxID).style.display = "block";
	document.getElementById('rLoginUsername').focus();
}

function closeLogin(overlayID,boxID) {
	document.getElementById(boxID).style.display = "none";
	document.getElementById(overlayID).style.display = "none";
}

function doKeyPressLogin(e) {
        // look for window.event in case event isn't passed in
        if (window.event) { e = window.event; }
        if (e.keyCode == 13)
        {
					doLogin('loginDispBox','rLoginUsername','rLoginPassword');
        }
}

function doKeyPressLoginCheckout(e) {
        // look for window.event in case event isn't passed in
        if (window.event) { e = window.event; }
        if (e.keyCode == 13)
        {
					doLogin('loginDispBoxChkOut','rLoginUsernameF','rLoginPasswordF');
        }
}

function doLogin(dispBoxID,usernameFld,passwordFld) {
	if (checkLoginForm(usernameFld,passwordFld)) {
		var usernameField = document.getElementById(usernameFld).value;
		var passwordField = document.getElementById(passwordFld).value;
		var obj = document.getElementById(dispBoxID);
		obj.innerHTML = "<div class=\"ajaxLoadingLogin\"></div>";
		var formData = new FormData();
    formData.append('ajxDo', 'checkLogin');
    formData.append('rLoginUsername', usernameField);
    formData.append('rLoginPassword', passwordField);
    var serverPage = global_site_name+"inc/ajx-parse/check-login.php";
		xmlhttp.open('POST', serverPage, true);
		xmlhttp.send(formData);
		/*var serverPage = global_site_name+"inc/ajx-parse/check-login.php?ajxDo=checkLogin&lgnUsername="+usernameField+"&lgnPassword="+passwordField;
		xmlhttp.open("GET", serverPage);
		xmlhttp.setRequestHeader("If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT");*/
		xmlhttp.onreadystatechange = function() {
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				if (xmlhttp.responseText=="loginSuccess") {
					document.location.reload();
				} else if (xmlhttp.responseText=="loginNotActivated") {
					obj.innerHTML = "<div class=\"ajaxMessageLogin\">Account not activated yet, check your sign-up confirmation email.</div>";
				} else {
					obj.innerHTML = "<div class=\"ajaxMessageLogin\">Login failed, please check your username and password again.</div>";
				}
			}
		}
		xmlhttp.send(null);
	}
}

function doKeyPressSearchMain(e) {
        // look for window.event in case event isn't passed in
        if (window.event) { e = window.event; }
        if (e.keyCode == 13)
        {
					doSearch();
        }
}

function doSearch() { 
	var srchKey = document.getElementById('crSearch').value;
	if (srchKey!="") {
			var newURLStr = global_site_name + "catalog";
			newURLStr = newURLStr + "/?srch=" + convertSearchString(srchKey);
			goURL(newURLStr);
	} else {
			alert('Anda belum memasukkan kata kunci untuk pencarian yang anda inginkan');	
			document.getElementById('crSearch').focus();
	}
}

function addItemToCart(cartPageUrl) {
	var newCookieValue = "";
	var currCookieValue=getCookie(cartCookieName);
	/* parsed value */
	var purchaseQty = 0;
	var vBuyPrdID = Number(document.getElementById('buyPrdID').value);
	var vBuyQty = Number(document.getElementById('buyPrdQty').value);
	var vBuyWholesale = document.getElementById('buyPrdWholesale').value;
	var isWholesale = 0;
	if (vBuyWholesale=="wholesale") { isWholesale = 1; }
	if (vBuyQty=="" || vBuyPrdID<=0 || vBuyPrdID=="NaN") { vBuyQty = 1; }
	if (vBuyPrdID!="" && vBuyPrdID>0 && vBuyPrdID!="NaN") {
		newCookieValue = vBuyPrdID+","+vBuyQty+","+isWholesale;
	}
	/* save to cookie */
	if (newCookieValue!=null && newCookieValue!="") {
			if (currCookieValue!=null && currCookieValue!="") { 
					newCookieValue = currCookieValue + "|" + newCookieValue; 
			} 
			setCookie(cartCookieName,newCookieValue,1);
	}
	goURL(cartPageUrl);
	//getBasketAmount();
	/* alert result */
	/*if (purchaseCount>0) {
		alert(purchaseQty + " item belanja ditambahkan ke shopping cart.");
	} else {
		alert("Anda belum menentukan jumlah barang yang anda inginkan.");
	}*/
}

function removeCartItem(countNumber) {
	if (countNumber!=null) {
		/* remove cart items from cookie string */
		var newCartStr = "";
		var cartBasket = getCookie(cartCookieName);
		var cartArray = cartBasket.split("|");
		for (var x=0; x < cartArray.length; x++) {
			if (countNumber!=x) {
				if (newCartStr!=null && newCartStr!="") { newCartStr=newCartStr + "|"; }
				newCartStr = newCartStr+cartArray[x];
			}
		}
		setCookie(cartCookieName,newCartStr,1);
		if (newCartStr=="") { location.reload(); }
		/* remove cart items from row display */
		var rowObj = document.getElementById('cartRow_' + countNumber);
		rowObj.parentNode.removeChild(rowObj);
		calculateCartSumTotal(localFormat);
	}
}

function getBasketAmount() {
	var totalItem = 0;
	var cartDisp = document.getElementById('yourCartBox');
	var cartBasket = getCookie('itsCart0514');
	var myarray = cartBasket.split("|");
	var itemArray = "";
	var totalQty = 0;
	totalItem = myarray.length;
	for (var x=0; x < myarray.length; x++) {
		itemArray = myarray[x].split(";");
		totalQty = totalQty+(itemArray[3]*1);
	}
	if (totalItem>0 && getCookie('itsCart0514')!="") {
		cartDisp.innerHTML = "<b>" + totalQty + "</b> item(s)";
	} else {
		cartDisp.innerHTML = "-";
	}
}

function goCheckout() {
	var cartBasket=getCookie('itsCart0514');
	if (cartBasket=="") {
		alert("There are no purchased items yet in your shopping cart. Please choose your shopping product first before checking out.");
		//goURL('./product/daily-products');
		return false;
	} else {
		goURL('./checkout');
	}
}

function calculateCartGrandTotal(localFormat) {
	var grandTotal = 0;
	var cartCurrency = document.getElementById("crtCurrency").value;
	var sumTotal = Number(document.getElementById("crtTotal").value);
	var sumDelivery = Number(document.getElementById("crtDelivery").value);
	grandTotal = sumTotal + sumDelivery;
	document.getElementById("crtBill").value = grandTotal;
	document.getElementById("cartBillDisp").innerHTML = cartCurrency + " " + convertPrice(localFormat,grandTotal);
}

function calculateCartSumTotal(localFormat) {
	var itemTotal = 0;
	var sumTotal = 0;
	var cartCurrency = document.getElementById("crtCurrency").value;
	var arr = document.getElementsByName('crtAmount[]');
  for(var i=0;i<arr.length;i++){
      if(parseInt(arr[i].value))
          sumTotal += parseInt(arr[i].value);
  }
	document.getElementById("crtTotal").value = sumTotal;
	document.getElementById("cartTotalDisp").innerHTML = cartCurrency + " " + convertPrice(localFormat,sumTotal);
	calculateCartGrandTotal(localFormat);
}

function getProvinceOpt(pageType,countryFieldName,provinceFieldName,provinceObj,selectedValue,selectedCity) {
	var countryID = document.getElementById(countryFieldName).value;
	var objLoad = document.getElementById('loadProvince');
	var obj = document.getElementById(provinceObj);
	objLoad.style.display = "block";
	var serverPage = global_site_name+"inc/ajx-parse/form-field-province.php?ajxDo=getProvinceField&sPage=" + pageType + "&sCountryID=" + countryID + "&sProvinceFN=" + provinceFieldName + "&sSelected=" + selectedValue;
	xmlhttp.open("GET", serverPage);
	xmlhttp.setRequestHeader("If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT");
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			obj.innerHTML = xmlhttp.responseText;
			if (selectedCity!="") {
				getCityOpt(pageType,'rgProvince','rgCity','cityOption',selectedCity,'');
			}
		}
	}
	xmlhttp.send(null);
}

function getCityOpt(provinceFieldName,cityFieldName,cityObj,selectedValue,varClassName) {
	var provinceID = document.getElementById(provinceFieldName).value;
	var objLoad = document.getElementById('loadCity');
	var obj = document.getElementById(cityObj);
	objLoad.style.display = "block";
	var serverPage = global_site_name+"inc/ajx-parse/form-field-city.php?ajxDo=getCityField&sProvinceID=" + provinceID + "&sCityFN=" + cityFieldName + "&sSelected=" + selectedValue + "&className=" + varClassName;
	xmlhttp.open("GET", serverPage);
	xmlhttp.setRequestHeader("If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT");
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			obj.innerHTML = xmlhttp.responseText;
			objLoad.style.display = "none";
		}
	}
	xmlhttp.send(null);
}

function calculateDeliveryCost(localFormat,sourceID) {
	var vCityID = document.getElementById(sourceID).value;
	if (vCityID!=null && vCityID>0) {
		var vCurrency = document.getElementById('crtCurrency').value;
		var objDisp = document.getElementById('cartDeliveryDisp');
		var objValue = document.getElementById('crtDelivery');
		var objLoad = document.getElementById('loadDelivery');
		objLoad.style.display = "block";
		var serverPage = global_site_name+"inc/ajx-parse/calculate-delivery-cost.php?ajxDo=getDeliveryCost&sCityID=" + vCityID;
		xmlhttp.open("GET", serverPage);
		xmlhttp.setRequestHeader("If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT");
		xmlhttp.onreadystatechange = function() {
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				var retResult = xmlhttp.responseText;
				if (retResult!="") {
					if (retResult=="free") {
						objValue.value = 0;
						objDisp.innerHTML = "<i>free</i>";
					} else {
						objValue.value = retResult;
						//objDisp.innerHTML = vCurrency + " " + addSeparatorsNF(retResult, '.', ',', '.');
						objDisp.innerHTML = vCurrency + " " + convertPrice(localFormat,retResult);
					}
				} else {
					objValue.value = 0;
					objDisp.innerHTML = "-";
				}
				objLoad.style.display = "none";
				calculateCartGrandTotal(localFormat);
			}
		}
		xmlhttp.send(null);
	}
}

function calculateCartQuantity(localFormat,countNumber,minQuantity,maxQuantity) {
	var itemTotal = 0;
	var itemQty = document.getElementById("crtQuantity_" + countNumber).value;
	var cartCurrency = document.getElementById("crtCurrency").value;
	var itemPrice = document.getElementById("crtBasePrice_" + countNumber).value;
	if (minQuantity<=0) { minQuantity = 1; }
	if (maxQuantity<=0) { maxQuantity = 100; }
	if (itemQty<minQuantity) {
		itemQty = minQuantity;
		alert("The minimum purchase quantity is " + itemQty);
		document.getElementById("crtQuantity_" + countNumber).value = itemQty;
	} else if (itemQty>maxQuantity) {
		itemQty = maxQuantity;
		alert("The maximum purchase quantity is " + itemQty);
		document.getElementById("crtQuantity_" + countNumber).value = itemQty;
	}
	if (itemQty>0) {
		itemTotal = itemQty * itemPrice;
	} else {
		itemQty = 1;
		document.getElementById("cartQty_" + countNumber).value = itemQty;
		itemTotal = itemQty * itemPrice;
	}
	document.getElementById("crtAmount_" + countNumber).value = itemTotal;
	document.getElementById("cartAmountDisp_" + countNumber).innerHTML = cartCurrency + " " + convertPrice(localFormat,itemTotal);
	calculateCartSumTotal(localFormat);
}

function updateCartQty(localFormat,countNumber) {
	if (countNumber!=null) {
		var vTtlPrice = 0;
		var vCurrency = document.getElementById('chkOutCrcy').value;
		var vQuantity = document.getElementById('chkOutQty_' + countNumber).value;
		var vCurrQuantity = document.getElementById('chkOutCurrQty_' + countNumber).value;
		//if (vQuantity<=0 || vQuantity==null || vQuantity<vCurrQuantity) { 
		if (vQuantity<=0 || vQuantity==null) { 
			vQuantity = vCurrQuantity; 
			document.getElementById('chkOutQty_' + countNumber).value = vQuantity;
		}
		var vPrice = document.getElementById('chkOutPrc_' + countNumber).value;
		var vCashbackTrm = document.getElementById('chkOutCshBTrm_' + countNumber).value;
		var vCashback = document.getElementById('chkOutCshB_' + countNumber).value;
		var vDiscountTrm = document.getElementById('chkOutDscTrm_' + countNumber).value;
		var vDiscount = document.getElementById('chkOutDsc_' + countNumber).value;
		var dispCashB = document.getElementById('chkOutItmCshB' + countNumber);
		var dispDisc = document.getElementById('chkOutItmDisc' + countNumber);
		var dispTtlPrc = document.getElementById('chkOutItmTtlPrc' + countNumber);
		dispCashB.innerHTML = "<div class=\"ajaxLoadingLogin\"></div>";
		dispDisc.innerHTML = "<div class=\"ajaxLoadingLogin\"></div>";
		dispTtlPrc.innerHTML = "<div class=\"ajaxLoadingLogin\"></div>";
		
		/* calculate cashback */
		vPrice = vPrice*vQuantity;
		vCashback = getDiscountAmount(vCashbackTrm,vCashback,vPrice);
		if (vCashback>0) { 
			vPrice = vPrice - vCashback;
			vCashback = vCurrency + " " + convertPrice(localFormat,vCashback); 
		} else { 
			vCashback = "-"; 
		}
		dispCashB.innerHTML = vCashback;
		
		/* calculate discount */
		vDiscount = getDiscountAmount(vDiscountTrm,vDiscount,vPrice);
		if (vDiscount>0) {  
			vPrice = vPrice - vDiscount;
			vDiscount = vCurrency + " " + convertPrice(localFormat,vDiscount);
		} else { 
			vDiscount = "-"; 
		}
		dispDisc.innerHTML = vDiscount;
		
		/* calculate item total amount */
		document.getElementById('chkOutCurrQty_' + countNumber).value = vQuantity;
		document.getElementById('chkOutAmount_' + countNumber).value = vPrice;
		if (vPrice>0) { 
			vPrice = vCurrency + " " + convertPrice(localFormat,vPrice); 
		} else {
			vPrice = "-"; 
		}
		dispTtlPrc.innerHTML = vPrice;
		/* count cart total amount */
		calculateTotalCartAmount(localFormat);
	}
}

function getDiscountAmount(calcTerm,calcValue,calcPrice) {
	var retValue = 0;
	if (calcValue>0 && calcPrice>0) {
		if (calcTerm=="percentage") {
			retValue = Math.round((calcValue/100) * calcPrice);
		} else {
			retValue = Math.round(calcValue);
		}
	}
	return retValue;
}

function goPage(pageType,pageNum) {
	if (pageNum!="") {
		document.getElementById('pgCurrPage').value = pageNum;
		reloadListing(pageType);
	}
}

function convertSearchString(searchText) {
	var retValue="";
	if (searchText!="") {
		retValue = searchText;
		retValue = retValue.trim();
		retValue = retValue.replace(/\s+/g, " ");
		retValue = retValue.replace(/\+/gi,'%2B');
		retValue = retValue.replace(/ /gi,'+');
	}
	return retValue;
}

function checkboxFltrPrice(opt) {
	var vPriceOpt = document.getElementsByName('fltrPrice');
	for(var i = 0; i < vPriceOpt.length; ++i) {
		if (i!=opt) {
			vPriceOpt[i].checked = false;
		}
	}
}

function filterListing(pageType) {
	var pgPos = document.getElementById('pgCurrPage').value; /* current page position */
	var vBrands = document.getElementsByName('fltrBrand');
	var strBrands = "";
	for(var i = 0; i < vBrands.length; ++i) {
	    if(vBrands[i].checked) { 
	    	if (strBrands!="") { strBrands = strBrands + ","; }
	    	strBrands = strBrands + vBrands[i].value;
	    }
	}
	reloadListing(pageType);
}

function getSearchCategory(catID,catTitle) {
	var catDisplay = document.getElementById('selSearchCategory');
	catDisplay.innerHTML = catTitle.toUpperCase(); 
	document.getElementById('crSearchCat').value = catID;
	document.getElementById('searchSub').style.display = "none";
}

function calculateTotalCartAmount(localFormat) {
	var vTotalPurchase = 0;
	var vCurrency = document.getElementById('chkOutCrcy').value;
	var vItmAmount = document.getElementsByName('chkOutAmount[]');
	for(var i = 0; i < vItmAmount.length; ++i) {
	    if(vItmAmount[i].value!=null && vItmAmount[i].value>0) { 
	    	vTotalPurchase = vTotalPurchase + (vItmAmount[i].value * 1);
	    }
	}
	if (vTotalPurchase!=null && vTotalPurchase>0) {
		document.getElementById('chkOutSumTtlN').value = vTotalPurchase;
		vTotalPurchase = vCurrency + " " + convertPrice(localFormat,vTotalPurchase);
	} else {
		document.getElementById('chkOutSumTtlN').value = "";
		vTotalPurchase = "-";
	}
	document.getElementById('chkOutSumTtl').innerHTML = vTotalPurchase;
	calculateGrandTotal(localFormat);
}

function unvealBriefCover(boxID,boxCoverID) {
	var contentBox = document.getElementById(boxID);
	var contentCover = document.getElementById(boxCoverID);
	if (contentCover.style.display=="none") {
		contentCover.style.display = "block";
		contentBox.setAttribute('class', 'updtBrief');
	} else {
		contentCover.style.display = "none";
		contentBox.setAttribute('class', 'updtBriefUnveal');
	}
}

function submitProductRequest() {
	var rqName = document.getElementById('rqName').value;
	var rqPhone = document.getElementById('rqPhone').value;
	var rqEmail = document.getElementById('rqEmail').value;
	var rqProduct = document.getElementById('rqProduct').value;
	var rqMessage = document.getElementById('rqMessage').value;
	var obj = document.getElementById('formLoading');
	var loadingStr = "<div class=\"tooltipLoading\"><img src=\"i/ajx-loading.gif\"></div>";
	obj.style.display = 'block';
	obj.innerHTML = loadingStr;
	var serverPage = global_site_name+"inc/ajx-parse/send-product-request.php?ajxDo=sendProductRequest&rqName="+rqName+"&rqPhone="+rqPhone+"&rqEmail="+rqEmail+"&rqProduct="+rqProduct+"&rqMessage="+rqMessage;
	xmlhttp.open("GET", serverPage);
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			if (xmlhttp.responseText=="success") {	
				obj.innerHTML = "<div class=\"tooltipLoading\">Permintaan anda sudah dikirim, silahkan tunggu dan team kami akan menghubungi anda kembali.<div style=\"margin-top:10px;\"><a href=\"javascript:;\" class=\"hidemodal\" onClick=\"$('#lean_overlay').click();\">Klik disini untuk menutup <i>window</i> ini</a></div></div>";
			} else {
				obj.innerHTML = "<div class=\"tooltipLoading\">Permintaan anda tidak dapat kami proses dikarenakan gangguan pada sistem kami. Silahkan kirimkan permintaan anda ke email kami store@alex58.com.<div style=\"margin-top:10px;\"><a href=\"javascript:;\" class=\"hidemodal\" onClick=\"$('#lean_overlay').click();\">Klik disini untuk menutup <i>window</i> ini</a></div></div>";
			}
		}
	}
	xmlhttp.send(null);
}

function loadMoreNews(groupID,catID,limit) {
		var lastLoaded = document.getElementById('newsLoaded');
		var foundset = document.getElementById('foundset').value;
		var nowDate = document.getElementById('todayDate').value;
		var loadObj = document.getElementById('loadingMore');
		loadObj.style.display = "block";
		$.get(global_site_name+'inc/ajx-parse/load-more-news.php?ajxDo=loadMoreNews&min='+lastLoaded.value+'&grp='+groupID+'&cat='+catID+'&max='+limit+'&dt='+nowDate, '', function(newitems){
				var data = eval("("+newitems+")");
				$('#newsArea').append(data.htmlWrite);
				document.getElementById('newsLoaded').value=data.lastLoadedCount;
				loadObj.style.display = "none";
				if (data.lastLoadedCount >= foundset) {
					document.getElementById('loadMoreNews').style.display = "none";
				}
		});
}

function loadMoreProduct(wholesaleTag,groupID,catID,limit) {
		var lastLoaded = document.getElementById('productLoaded');
		var foundset = document.getElementById('foundset').value;
		var loadObj = document.getElementById('loadingMore');
		loadObj.style.display = "block";
		$.get(global_site_name+'inc/ajx-parse/load-more-product.php?ajxDo=loadMoreProduct&min='+lastLoaded.value+'&tp='+wholesaleTag+'&grp='+groupID+'&cat='+catID+'&max='+limit, '', function(newitems){
				var data = eval("("+newitems+")");
				$('#shopArea').append(data.htmlWrite);
				document.getElementById('productLoaded').value=data.lastLoadedCount;
				loadObj.style.display = "none";
				if (data.lastLoadedCount >= foundset) {
					document.getElementById('loadMoreProduct').style.display = "none";
				}
		});
}

function processShopping() {
		var loadObj = document.getElementById('cartFormLoading');
		loadObj.style.display = "block";
}

function checkEmailValid(strEmail) {
	var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
	if (testEmail.test(strEmail)) {
	    return true;
	} else {
			return false;
	}
}

function bookingUpdateArrivalDate() {
	var bookindDate = document.getElementById('arrivalDate').value;
	var arrDate = bookindDate.split("/");
	document.getElementById('frommonth').value = arrDate[0];
	document.getElementById('fromday').value = arrDate[1];
	document.getElementById('fromyear').value = arrDate[2];
}

function removeFromDelimited(strList, keyValue, separator) {
	separator = separator || ",";
  var values = strList.split(separator);
  for(var i = 0 ; i < values.length ; i++) {
    if(values[i] == keyValue) {
      values.splice(i, 1);
      return values.join(separator);
    }
  }
  return strList;
}

function recaptchaLoaded() {
    
    document.querySelectorAll('.g-recaptcha').forEach((el, i) => {
        var widgetId = grecaptcha.render(el);
        el.setAttribute('data-grecaptcha-id', widgetId);
    });

}

function hotelBooking(myForm){
	var mandatoryCode = 0;
	//var hotelID = document.getElementsByClassName("Hotelnames").value;
	var hotelID = myForm.Hotelnames.value;
	$(".bookingLoading").fadeIn();
	if (hotelID == "BHJYP1111") {
		/* SANHA IBE */
		var currentDate = new Date();
		var todayDate = currentDate.toISOString().slice(0, 10);
		currentDate.setDate(currentDate.getDate() + 1);
		var tomorrowDate = currentDate.toISOString().slice(0, 10);
		var parseVar = "";
		//var chkInDt = document.getElementById("arrivalDate").value;
		var chkInDt = myForm.arrivalDate.value;
		if (chkInDt=="") { chkInDt = todayDate; }
		//var chkOutDt = document.getElementById("departureDate").value;
		var chkOutDt = myForm.departureDate.value;
		if (chkOutDt=="") { chkOutDt = tomorrowDate; }
		var numRooms = 1;
		//var numAdults = document.getElementById("adulteresa").value;
		var numAdults = myForm.adulteresa.value;
		if (numAdults=="") { numAdults = 0; }
		//var numChild = document.getElementById("enfantresa").value;
		var numChild = myForm.enfantresa.value;
		if (numChild=="") { numChild = 0; }
		var lang = "EN";
		//var promoCd = document.getElementById("AccessCode").value;
		myForm.AccessCode.value = myForm.usrCd.value;
		if (myForm.usrCd.value=="" && myForm.mbrCd2.value!="") { myForm.AccessCode.value=myForm.mbrCd2.value; }
		var promoCd = myForm.AccessCode.value;
		/*if (chkInDt!="") { 
			if (parseVar!="") { parseVar = parseVar+"&"; }
			parseVar += "check_in="+chkInDt; 
		}
		if (chkOutDt!="") { 
			if (parseVar!="") { parseVar = parseVar+"&"; }
			parseVar += "check_out="+chkOutDt; 
		}
		if (numRooms>0) { 
			if (parseVar!="") { parseVar = parseVar+"&"; }
			parseVar += "rooms="+numRooms; 
		}
		if (numAdults>0) { 
			if (parseVar!="") { parseVar = parseVar+"&"; }
			parseVar += "adult="+numAdults; 
		}
		if (numChild>0) { 
			if (parseVar!="") { parseVar = parseVar+"&"; }
			parseVar += "children="+numChild; 
		}
		if (promoCd!="") { 
			if (parseVar!="") { parseVar = parseVar+"&"; }
			parseVar += "prm_seq_no="+promoCd; 
		}
		if (lang!="") { 
			if (parseVar!="") { parseVar = parseVar+"&"; }
			parseVar += "lang_type="+lang; 
		}*/
		parseVar = "lang_type="+lang+"&check_in="+chkInDt+"&check_out="+chkOutDt+"&rooms="+numRooms+"&adult="+numAdults+"&children="+numChild+"&prm_code="+promoCd; 
		if (parseVar!="") { parseVar = "?"+parseVar; }
		//https://be4.wingsbooking.com/PWH1/roomSelect?check_in=2021-04-05&check_out=2021-04-06&rooms=1&adult=2&children=0&prm_seq_no=&cpny_seq_no=&lang_type=EN
		//var targetURL = "https://be4.wingsbooking.com/"+hotelID+"/roomSelect";
		var targetURL = "https://be4.wingsbooking.com/"+hotelID;
		window.location = targetURL+parseVar;
	    $(".bookingLoading").fadeOut();
	} else {
		/* FASTBOOKING IBE */
	    if (mandatoryCode == 1 && myForm.AccessCode.value == "") {
	        alert("You must type in your code ID");
	        return (false);
	    }
	    myForm.AccessCode.value = myForm.usrCd.value;
		if (myForm.usrCd.value=="" && myForm.mbrCd.value!="") { myForm.AccessCode.value=myForm.mbrCd.value; }
	    myForm.action = FBRESA + "dispoprice.phtml";
	    if (FB_useGoogleAnalytics) {
	        sessId = generateSession();
	        profilValue = escape("SESSION=" + sessId + "&CODE=GoogleAnalytics");
	        if ((typeof myForm.profil) == "undefined") {
	            var newInput = document.createElement("input");
	            newInput.setAttribute("type", "hidden");
	            newInput.setAttribute("name", "profil");
	            newInput.setAttribute("value", profilValue);
	            myForm.appendChild(newInput);
	        } else {
	            myForm.profil.value = profilValue;
	        }
	    }
	    //myForm.target="_blank";
	    myForm.submit();
	    $(".bookingLoading").fadeOut();
	    if (FB_useGoogleAnalytics) {
	        var cname = "";
	        if ((typeof myForm.AccountName) != "undefined" && myForm.AccountName.value != "")
	            cname = myForm.AccountName.value;
	        else
	            cname = myForm.Clusternames.value;
	        transferGAdata(sessId, cname);
	    }
	    return (true);
	}
}

$(function() {
		$(window).load(function() {
				/* FUNCTIONS */
				jQuery.fn.extend({
						/* HIDE SHOW BOOKING PANEL */
						 closeAlert: function(objAlert,objAlertMsg) {
				    	 	objAlert.fadeOut(function() {
		    	 	 			objAlert.removeClass('successAlert');
		    	 				objAlertMsg.html('');
				    	 	});
					     },
					    
						 bookingUpdateArrivalDate: function(enThis,thisDate) {
						 		var arrDate = thisDate.split("-");
						 		enThis.siblings("#frommonth").val(arrDate[1]);
						 		enThis.siblings("#fromday").val(arrDate[2]);
						 		enThis.siblings("#fromyear").val(arrDate[0]);
								/*document.getElementById('frommonth').value = arrDate[0];
								document.getElementById('fromday').value = arrDate[1];
								document.getElementById('fromyear').value = arrDate[2];*/
						 },

						 bookingUpdateDepartureDate: function(enThis,thisDate) {
								var arrDate = thisDate.split("-");
								enThis.siblings("#tomonth").val(arrDate[1]);
						 		enThis.siblings("#today").val(arrDate[2]);
						 		enThis.siblings("#toyear").val(arrDate[0]);
								/*document.getElementById('tomonth').value = arrDate[0];
								document.getElementById('today').value = arrDate[1];
								document.getElementById('toyear').value = arrDate[2];*/
						 },
						 
						 convertDateFormat: function(thisFormat,thisDate) {
								var formatedDate = thisDate;
								var arrDate = thisDate.split("-");
								var dateDay = arrDate[2];
								var dateMonth = arrDate[1];
								var dateYear = arrDate[0];
								if (thisFormat==1) {
										var dateMonthName = monthNames[dateMonth*1];
										formatedDate = dateDay + "/" + dateMonthName + "/" + dateYear;
								}
								return formatedDate;
						 },
						 
						 displayBookingDate: function() {
						 		var checkInDate = "";
						 		var checkOutDate = "";
						 		if ($("#bookCheckIn").length) { checkInDate = $("#bookCheckIn").val(); }
						 		if ($("#bookCheckOut").length) { checkOutDate = $("#bookCheckOut").val(); }
						 		if ($("#showStayDate").length) {
						 				if (checkInDate!="" || checkOutDate!="") {
						 						var dateStr = "";
						 						if (checkInDate!="") { 
						 							if (dateStr!="") { dateStr = dateStr + " <span>~</span> "; }
						 							dateStr = dateStr + $.fn.convertDateFormat(1,checkInDate); 
						 						}
						 						if (checkOutDate!="") { 
						 							if (dateStr!="") { dateStr = dateStr + " <span>~</span> "; }
						 							dateStr = dateStr + $.fn.convertDateFormat(1,checkOutDate); 
						 						}
						 						$("#showStayDate").html(dateStr);
						 				} else {
						 						$("#showStayDate").html("<i>Use calendar to pick your stay date</i>");
						 				}
						 		}
						 },
						 
						 displayEventDate: function() {
						 		var eventDate = "";
						 		if ($("#frmFldEventDate").length) { eventDate = $("#frmFldEventDate").val(); }
						 		if ($("#showEventDate").length) {
						 				if (eventDate!="") {
						 						var dateStr = "";
						 						if (eventDate!="") { 
						 							if (dateStr!="") { dateStr = dateStr + " <span>~</span> "; }
						 							dateStr = dateStr + $.fn.convertDateFormat(1,eventDate); 
						 						}
						 						$("#showEventDate").html(dateStr);
						 				} else {
						 						$("#showEventDate").html("<i>Use calendar to pick your event date</i>");
						 				}
						 		}
						 },
						 
						 initiateCalendarShow: function() {
						 		if ($("#frmFldShowDate").length) {
						 				$("#frmFldShowDate").datepicker({
												altField: '#frmFldEventDate',
												rangeSelect: true,
												dateFormat: 'yy-mm-dd',
												minDate: 0,
												onSelect: function( selectedDate ) {
													/* DISPLAY SELECTED DATE */
													$.fn.displayEventDate();
												}
										});
						 		}
						 		if ($("#frmFldEventDate").length) {
						 				$("#frmFldEventDate").datepicker({
												rangeSelect: true,
												dateFormat: 'yy-mm-dd',
												minDate: 0
										});
						 		}
						 		if ($(".bookFldDate").length) {
										$(".bookFldDate.startDate").datepicker({
												rangeSelect: true,
												dateFormat: 'yy-mm-dd',
												minDate: 0,
												onSelect: function( selectedDate ) {
													if ($( ".bookFldDate.endDate" ).length) {
														$.fn.bookingUpdateArrivalDate($(this),selectedDate);
														var nextDay = new Date(selectedDate);
														nextDay.setDate(nextDay.getDate() + 1);
												    var outDate = nextDay.getFullYear() + '-' + (nextDay.getMonth() + 1) + '-' + nextDay.getDate();
														$.fn.bookingUpdateDepartureDate($(this),outDate);
														$( ".bookFldDate.endDate" ).val(outDate);
														$( ".bookFldDate.endDate" ).datepicker( "option", "minDate", outDate );
													}
												}
										});
										$(".bookFldDate.endDate").datepicker({
												rangeSelect: true,
												dateFormat: 'yy-mm-dd',
												defaultDate: +1,
												minDate: +1,
												onSelect: function( selectedDate ) {
													if ($( ".bookFldDate.startDate" ).length) {
														$.fn.bookingUpdateDepartureDate($(this),selectedDate);
														$( ".bookFldDate.startDate" ).datepicker( "option", "maxDate", selectedDate );
													}
												}
										});
								}
						 },
						 
						 initiateDatePickerShow: function() {
						 		if ($("#qckBookInCal").length) {
										$("#qckBookInCal").datepicker({
												altField: '#bookCheckIn',
												rangeSelect: true,
												dateFormat: 'yy-mm-dd',
												minDate: 0,
												onSelect: function( selectedDate ) {
													if ($( "#qckBookOutCal" ).length) {
														$.fn.bookingUpdateArrivalDate($(this),selectedDate);
														var nextDay = new Date(selectedDate);
														nextDay.setDate(nextDay.getDate() + 1);
												    var outDate = nextDay.getFullYear() + '-' + (nextDay.getMonth() + 1) + '-' + nextDay.getDate();
														$.fn.bookingUpdateDepartureDate($(this),outDate);
														$( "#qckBookOutCal" ).val(outDate);
														$( "#qckBookOutCal" ).datepicker( "option", "minDate", outDate );
														/* SET LINK TO BOOKING BAR DATE */
														if ($('.qckStartDt').length) {
																$('.qckStartDt').val(selectedDate);
																$.fn.bookingUpdateArrivalDate($('.qckStartDt'),selectedDate);
														}
														if ($('.qckEndDt').length) {
																$('.qckEndDt').val(outDate);
																$.fn.bookingUpdateArrivalDate($('.qckEndDt'),selectedDate);
														}
													}
													/* DISPLAY SELECTED DATE */
													$.fn.displayBookingDate();
												}
										});
										if ($('.qckStartDt').length) {
						    				$('#qckBookInCal').datepicker('setDate', new Date($('.qckStartDt').val()));
						    				$.fn.bookingUpdateArrivalDate($('.bkStartDt'),$('.qckStartDt').val());
						    		}
								}
								if ($("#qckBookOutCal").length) {
										$("#qckBookOutCal").datepicker({
												altField: '#bookCheckOut',
												rangeSelect: true,
												defaultDate: +1,
												minDate: +1,
												dateFormat: 'yy-mm-dd',
												onSelect: function( selectedDate ) {
													if ($( "#qckBookInCal" ).length) {
														$.fn.bookingUpdateDepartureDate($(this),selectedDate);
														$( "#qckBookInCal" ).datepicker( "option", "maxDate", selectedDate );
														/* SET LINK TO BOOKING BAR DATE */
														if ($('.qckEndDt').length) {
																$('.qckEndDt').val(selectedDate);
																$.fn.bookingUpdateDepartureDate($('.qckEndDt'),selectedDate);
														}
													}
													/* DISPLAY SELECTED DATE */
													$.fn.displayBookingDate();
												}
										});
										if ($('.qckEndDt').length) {
						    				$('#qckBookOutCal').datepicker('setDate', new Date($('.qckEndDt').val()));
						    				var nextDay = new Date($('.qckEndDt').val());
												var outDate = nextDay.getFullYear() + '-' + (nextDay.getMonth() + 1) + '-' + nextDay.getDate();
						    				$( "#qckBookOutCal" ).datepicker( "option", "minDate", outDate );
						    				$.fn.bookingUpdateDepartureDate($('.bkEndDt'),$('.qckEndDt').val());
						    		}
								}	
						 },
						 
						 initiateDropDown: function() {
						 		if ($(".qckBookSel, .selUi").length) {
										$(".qckBookSel, .selUi").selectmenu().selectmenu("menuWidget").addClass("selWrappedBox");
								}
						 },

						 closeModalPop: function(enThis) {
						 		var modalScrn = enThis.parents(".mdlScrn");
						 		var modalBox = enThis;
						 		var modalCnt = enThis.find(".mdlContent");
						 		var doCleanContent = enThis.find("a.btnMdlClose").data("cleancontent"); 
						 		modalBox.hide('slide', { direction: 'up' }, 300, function() {
						 			modalScrn.fadeOut(300);
						 			if (doCleanContent!="no") { modalCnt.html(''); }
									//$("body").removeClass("noScrollMbl");
						 		});
						 },

						 showModalPop: function(enThis) {
					    	var modalOverlay = enThis.parents('.mdlScrn');
					    	modalOverlay.fadeIn(function() {
					    		enThis.fadeIn();
					    		//$("body").addClass("noScrollMbl");
					    	});
					     },
						 
						 closeModalForm: function() {
								$('.bookMdlArea').hide('slide', { direction: 'up' }, 300, function() {
										$('.bookMdlScrn').fadeOut(300);
										$("body").removeClass("noScrollMbl");
								});
						 },
						 
						 showModalForm: function(enThis) {
						 		var mdlForm = enThis.attr("mdl-form");
						 		var mdlPromoCode = enThis.attr("mdl-promo-code");
						 		var mdlLocation = enThis.attr("mdl-location");
						 		var mdlLocale = enThis.attr("mdl-locale");
						 		var mdlSendTo = enThis.attr("mdl-to");
						 		var mdlHotel = enThis.attr("mdl-hotel");
						 		var loadingObj = $('.bookMdlLoading');
						 		if (mdlForm!="") {
						 		    if (mdlForm=="booking-widget") {
						 		        $('.bookMdlScrn').fadeIn(300, function() {
						 		              $('.bookMdlArea').show('slide', { direction: 'up' }, 300); 
						 		              $("#propertyIndex--select").val(mdlLocation).change();
						 		        });
						 		    } else {
							 			$.ajax({
											  method: "GET",
											  url: "./inc/files/form/"+mdlForm+".php",
											  data: { ajxDo:"openForm", locID:mdlLocation, promoCode:mdlPromoCode, sendTo:mdlSendTo, hotelName:mdlHotel, locale:mdlLocale },
											  cache: false,
											  beforeSend: function( xhr ) {
											   		loadingObj.fadeIn();
											  }
										}).done(function( returnText ) {
												if (returnText!="") {
														$('.bookMdlArea').html(returnText);
														$('.bookMdlScrn').fadeIn(300, function() {
																loadingObj.fadeOut('fast', function() {
																		$('.bookMdlArea').show('slide', { direction: 'up' }, 300);
																		$.fn.initiateDatePickerShow();
																		$.fn.initiateCalendarShow();
																		$.fn.initiateDropDown();
																		if (mdlForm=="meeting-form") { recaptchaLoaded(); }
																		if (mdlForm=="claim-form") {
																			$.fn.formSubmitClaim($("#formClaimPrice"));
																		} else if (mdlForm=="booking-form") {
																			$.fn.initializeBookingFormLink();
																			$.fn.initializeBookingBarLink();
																		}
																		$.fn.formSubmitAction($("#formInquiry"));
																		$("body").addClass("noScrollMbl");
																});
														});
												}
										});
									}
						 		}
						 },
						 
						 trimThisField: function(enThis) {
						 		if (enThis.length) {
							 		enThis.each(function() {
							        $(this).val($.trim($(this).val()));
							    });	
							  }
						 },
						 
						 /* FORM SUBMIT */
					    formSubmitClaim: function(enThis) {
					    		enThis.ajaxForm({ 
									 			target: '#frmTarget', 
								 				beforeSubmit:function() {
								 						$.fn.trimThisField($("input[type=text]"));
								 						$('#signinBtn').prop("disabled", true);
								            $('#frmClaimLoading').fadeIn('slow');
								        },
								        success: function() { 
								        		$('#frmClaimLoading').fadeOut('fast', function() {
								        			var str = $('#frmTarget').html();
								        			var arrStr = str.split("[|]");
								        			if (arrStr[0]=="Success") {
								        				
								        			} else if (arrStr[0]=="Refresh") {
								        				location.reload(true);
								        			} else if (arrStr[0]=="Go-link") {
								        				goURL(arrStr[1]);
								        			} else {
									        			$('#frmAlert').html(arrStr[1]);
									        			$("#frmAlert").show(300);
									        		}
								        		});
								        } 
									 });
								   $('#signinBtn').prop("disabled", false);
					    },
					    
					    formSubmitSubscribe: function(enThis) {
					    		enThis.ajaxForm({ 
									 			target: '#frmSubcrTarget', 
								 				beforeSubmit:function() {
								 						$.fn.trimThisField($("input[type=text]"));
								 						$('#subscribeBtn').prop("disabled", true);
								 						$('#subscribeEmail').prop("disabled", true);
								            $('#subscribeLoading').fadeIn('slow');
								        },
								        success: function() { 
								        		$('#subscribeLoading').fadeOut('fast', function() {
								        			var str = $('#frmSubcrTarget').html();
								        			var arrStr = str.split("[|]");
								        			if (arrStr[0]=="success") {
								        				$('#subscribeAlert').html(arrStr[1]);
									        			$("#subscribeAlert").show(300);
								        			} else if (arrStr[0]=="Refresh") {
								        				location.reload(true);
								        			} else if (arrStr[0]=="Go-link") {
								        				goURL(arrStr[1]);
								        			} else {
									        			$('#subscribeAlert').html(arrStr[1]);
									        			$("#subscribeAlert").show(300);
									        		}
														  setTimeout(function(){ 
														  	$("#subscribeAlert").hide(300);
														  	$('#subscribeEmail').val("");
														  	$('#subscribeBtn').prop("disabled", false);
														 		$('#subscribeEmail').prop("disabled", false);
														 	}, 3000);
								        		});
								        } 
									 });
								   $('#subscribeBtn').prop("disabled", false);
								 	 $('#subscribeEmail').prop("disabled", false);
					    },
					    
					    formSubmitAction: function(enThis) {
					    		enThis.ajaxForm({ 
									 			target: '#formTarget', 
								 				beforeSubmit:function() {
								 						$.fn.trimThisField($("input[type=text]"));
								 						$('#formButton').prop("disabled", true);
								 						$("#formAlert").hide();
								 						$('#formAlert').html("");
								                        $('#formLoading').fadeIn('slow');
								        },
								        success: function() { 
								        		$('#formLoading').fadeOut('fast', function() {
								        			var str = $('#formTarget').html();
								        			var arrStr = str.split("[|]");
								        			if (arrStr[0]=="success") {
								        				$('#formAlert').html("<div class=\"alertDone\">"+arrStr[1]+"</div>");
								        				setTimeout(function(){ $.fn.closeModalForm($('.btnBookMdlClose')); }, 5000);
								        			} else if (arrStr[0]=="refresh") {
								        				location.reload(true);
								        			} else if (arrStr[0]=="go-link") {
								        				goURL(arrStr[1]);
								        			} else if (arrStr[0]=="show-text") {
								        			    $('#formContent').html(arrStr[1]);
								        			} else {
									        			$('#formAlert').html("<div class=\"alertErr\">"+arrStr[1]+"</div>");
									        			$("#formAlert").show(300);
									        		}
									        		$(".bookMdlArea").stop().animate({scrollTop: 0}, 900, 'swing');
									        		$('#formButton').prop("disabled", false);
								        		});
								        } 
									 });
								   $('#formButton').prop("disabled", false);
					    },
					    
					    formSubmitEditProfile: function(enThis) {
					        var frmTarget = enThis.find(".formTarget").attr("id");
					        var frmLoad = enThis.find(".frmLoading");
					        var edtFrmBx = enThis.parents(".editArea").find(".formEdt");
                			var edtDispBx = enThis.parents(".editArea").find(".edtBx");
                			var edtDispArea = edtDispBx.find(".edtDisplay");
                			var edtContentBx = edtDispBx.find(".edtShow");
					        enThis.ajaxForm({ 
					            target: '#'+frmTarget,
					            beforeSubmit:function() {
					                frmLoad.fadeIn();
					            },
					            success: function() { 
				                   var str = $('#'+frmTarget).html();
				                   var arrStr = str.split("[|]");
				                   if (arrStr[0]=="success") {
				                        edtContentBx.html(arrStr[1]);
				                   }
					                frmLoad.fadeOut('fast', function() {
					                    
                				        if ( arrStr[0]=="success" ) {
                				            $.fn.hideEditFields(edtDispArea);
                				        }
					                   enThis.find("input[type=submit]").prop("disabled", false);
					                });
					            }
					        });
					        enThis.find("input[type=submit]").prop("disabled", false);
					    },
					    /* -------- */
					    
					    /* FORM LINKING */
					    initializeBookingFormLink: function() {
					    		/* HOTEL SELECTION ON BOOKING FORM */
					    		if ($('.bkHotel').length) {
					    				$('.bkHotel').selectmenu({ 
					    					change: function( event, ui ) { 
					    						$('.qckHotel').val($(this).val()); 
					    					}
					    				});
					    		}
					    		/* ADULTS SELECTION ON BOOKING FORM */
					    		if ($('.bkAdults').length) {
					    				$('.bkAdults').selectmenu({ 
					    					change: function( event, ui ) { 
					    						$('.qckAdults').val($(this).val()); 
					    					}
					    				});
					    		}
					    		/* CHILDREN SELECTION ON BOOKING FORM */
					    		if ($('.bkChild').length) {
					    				$('.bkChild').selectmenu({ 
					    					change: function( event, ui ) { 
					    						$('.qckChild').val($(this).val()); 
					    					}
					    				});
					    		}
					    		/* PROMO CODE ON BOOKING FORM */
					    		if ($('.bkPromo').length) {
					    				$('.bkPromo').change(function() {
					    					$('.qckPromo').val($(this).val()); 
					    				});
					    		}
					    },
					    
					    initializeBookingBarLink: function() {
					    		/* HOTEL SELECTION ON BOOKING BAR */
					    		if ($('.qckHotel').length) {
					    				$('.bkHotel').val($('.qckHotel').val());
					    				$('.bkHotel').selectmenu('refresh');
					    		}
					    		/* ADULTS SELECTION ON BOOKING BAR */
					    		if ($('.qckAdults').length) {
					    				$('.bkAdults').val($('.qckAdults').val());
					    				$('.bkAdults').selectmenu('refresh');
					    		}
					    		/* CHILDREN SELECTION ON BOOKING BAR */
					    		if ($('.qckChild').length) {
					    				$('.bkChild').val($('.qckChild').val());
					    				$('.bkChild').selectmenu('refresh');
					    		}
					    		/* PROMO CODE ON BOOKING FORM */
					    		if ($('.qckPromo').length) {
					    				$('.bkPromo').val($(this).val()); 
					    		}
					    },
					    
					    initializeCountDown: function(targetDate) {
    					        var countDownDate = new Date(targetDate).getTime();
    
                                // Update the count down every 1 second
                                var x = setInterval(function() {
                                
                                  // Get today's date and time
                                  var now = new Date().getTime();
                                
                                  // Find the distance between now and the count down date
                                  var distance = countDownDate - now;
                                
                                  // Time calculations for days, hours, minutes and seconds
                                  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                                  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                                  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                                  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                                
                                  // Display the result in the element with id="demo"
                                  //document.getElementById("demo").innerHTML = days + "d " + hours + "h "
                                  //+ minutes + "m " + seconds + "s ";
                                  
                                  $(".timerDays").html(("0" + days).slice(-2));
                                  $(".timerHours").html(("0" + hours).slice(-2));
                                  $(".timerMinutes").html(("0" + minutes).slice(-2));
                                  $(".timerSeconds").html(("0" + seconds).slice(-2));
                                
                                  // If the count down is finished, write some text
                                  if (distance < 0) {
                                    clearInterval(x);
                                    //document.getElementById("demo").innerHTML = "EXPIRED";
                                  }
                                }, 1000);
					    },
					    
					    showEditFields: function(enThis) {
					            var objDisp = enThis.find(".mPrfDet");
        				        var objForm = enThis.find(".mPrfEdit");
        				        var objBtn = enThis.find(".mPrfEdtBtn");
        				        var objEdit = enThis.siblings(".editThis");
        				        var objCancel = enThis.siblings(".cancelEdit");
        				        $.fn.formSubmitEditProfile(enThis.find("form"));
        				        objEdit.removeClass("hideBtn");
        				        objCancel.addClass("showBtn");
        				        objDisp.fadeOut("fast", function() {
        				            objForm.fadeIn("fast");
        				            objBtn.fadeIn("fast");
        				        });
					    },
					    
					    hideEditFields: function(enThis) {
					            var objDisp = enThis.find(".mPrfDet");
        				        var objForm = enThis.find(".mPrfEdit");
        				        var objBtn = enThis.find(".mPrfEdtBtn");
        				        var objEdit = enThis.siblings(".editThis");
        				        var objCancel = enThis.siblings(".cancelEdit");
        				        objCancel.removeClass("showBtn");
        				        objEdit.addClass("hideBtn");
        				        objForm.fadeOut("fast", function() {
        				            objDisp.fadeIn("fast");
        				        });
        				        objBtn.fadeOut("fast");
					    }
					    /* ------------ */
				});
				
				var isMobile = false;
				/* DETECT MOBILE */
				if ( $('.tagMobile').is(":visible") ) { isMobile = true; }
				
				/* CLICK DIV */
				if ($("[filter=clickThis]").length) {
				   	$("[filter=clickThis]").click(function(e) {
						if ($(e.target).hasClass('edtBtn')) {
				   			return false;
				   		} else {
							if (typeof $(this).find("a:first").attr("href")==="undefined") {
						   			return false;
						   	} else {
									var linkTarget = $(this).find("a").attr("target");
									if (linkTarget=="_blank") {
										window.open($(this).find("a").attr("href"));
								 	} else {
								  		window.location = $(this).find("a").attr("href");
								 	} 
									return false;
							}
						}
					});
				}
				/* --------- */
				
				/* DROP MENU */
				if ($('.nvMenuArea').length) {
						if (!isMobile) {
								/* NAVIGATION DROP DOWN DESKTOP */
								$('.nvMenuArea').hoverIntent(
									  function() {
									  	 //$(this).find('.nvMenuDrop').show("slide", { direction: "up"}, 300);
									  	 $(this).find('.nvMenuDrop').fadeIn();
									  	 if ($(this).attr("menu-type")=="sub") {
									  	 		$('#locationList').hide('slide', { direction: 'right' }, 100, function (){
															$('#hotelNavigation').show('slide', { direction: 'left' }, 100);
													});
									  	 }
									  }, function() {
									  	 $(this).find('.nvMenuDrop').fadeOut();
									  }
								);
						} else {
								/* NAVIGATION DROP DOWN MOBILE */
								$('.nvMenuArea').click(function() {
										var dropMenu = $(this).find('.nvMenuDrop');
										if ( !dropMenu.is(":visible") ) { 
												dropMenu.fadeIn();
										}
								});
								$(window).scroll(function() {
										$('.nvMenuDrop').fadeOut(100);
								});
						}
				}
				if ($('.nvBack').length) {
						$('.nvBack').click(function() {
								$('#hotelNavigation').hide('slide', { direction: 'left' }, 100, function (){
										$('#locationList').show('slide', { direction: 'right' }, 100);
								});
						});
				}
				if ($('.nvNext').length) {
						$('.nvNext').click(function() {
								$('#locationList').hide('slide', { direction: 'right' }, 100, function (){
										$('#hotelNavigation').show('slide', { direction: 'left' }, 100);
								});
						});
				}
				/* --------- */
				
				/* HOME SCROLL DOWN */
				if ($('.goDown').length) {
						$(".goDown").click(function(event) {
				        event.preventDefault();
				        var targetID = $(this).attr("data-to");
				        $target = $('#'+targetID);
				        $('html, body').stop().animate({scrollTop: $target.offset().top}, 900, 'swing');
				        return false;
				    });
			  }
		    /* ---------------- */
				
				/* FIXED HEADER BAR ON SCROLL */
				if ($(".headerSection").length) {
						var panelAct = $('.btnDropUp').attr('close-act');
						var scrollPos = Math.ceil($(window).scrollTop());
						var headerHeight = Math.ceil($('.headerSection').height())+40;
    					if (!$('.stickyHeader.staySticky').length) {
    						if (scrollPos>headerHeight) {
    								$('.nvHeadLogo').hide();
    								$('#headerBar').addClass('stickyHeader');
    								$('.nvHeadSmLogo').fadeIn(100);
    								//$('#bookingButton').attr('click-act', 'panel');
    								if (panelAct==0) {
    									$('#bookingPanel').show('slide', { direction: 'up' }, 200);
    									$('.stickySpan').height(65);
    								}
    								/* SHOW BOOKING PANEL */
    						} else {
    								$('#headerBar').removeClass('stickyHeader');
    								$('.nvHeadSmLogo').hide();
    								$('#bookingButton').attr('click-act', 'popup');
    								$('#bookingPanel').hide();
    								$('.nvHeadLogo').fadeIn(100);
    								$('.stickySpan').height(0);
    						}
    				    }
						$(window).scroll(function() {
								var panelAct = $('.btnDropUp').attr('close-act');
								var scrollPos = Math.ceil($(window).scrollTop());
								var headerHeight = Math.ceil($('.headerSection').height())+40;
								if (!$('.stickyHeader.staySticky').length) {
    								if (scrollPos>headerHeight) {
    										$('.nvHeadLogo').hide();
    										$('#headerBar').addClass('stickyHeader');
    										$('.nvHeadSmLogo').fadeIn(100);
    										//$('#bookingButton').attr('click-act', 'panel');
    										if (panelAct==0) {
    											$('#bookingPanel').show('slide', { direction: 'up' }, 200);
    											$('.stickySpan').height(65);
    										}
    										/*$('#headerBar').addClass('stickyHeader', function() {
    											$('.nvHeadLogo').hide();
    											$('.nvHeadSmLogo').fadeIn(100);
    											$('#bookingButton').attr('click-act', 'panel');
    											if (panelAct==0) {
    												$('#bookingPanel').show('slide', { direction: 'up' }, 200);
    												$('.stickySpan').height(65);
    											}
    										});*/
    								} else {
    										$('#headerBar').removeClass('stickyHeader');
    										$('.nvHeadSmLogo').hide();
    										$('#bookingButton').attr('click-act', 'popup');
    										$('#bookingPanel').hide();
    										$('.nvHeadLogo').fadeIn(100);
    										$('.stickySpan').height(0);
    								}
    						   }
						});
				}
				
				/* DATEPICKER */
				$.fn.initiateDatePickerShow();
				
				/* SELECT BOOKING HOTEL */
				$.fn.initiateDropDown();
				
				/* SUBSCRIBE FORM */
				$.fn.formSubmitSubscribe($("#formSubscribe"));
				
				if ($(".bookFldDate").length) {
						$(".bookFldDate.startDate").datepicker({
								rangeSelect: true,
								dateFormat: 'yy-mm-dd',
								minDate: 0,
								onSelect: function( selectedDate ) {
									if ($( ".bookFldDate.endDate" ).length) {
										$.fn.bookingUpdateArrivalDate($(this),selectedDate);
										var nextDay = new Date(selectedDate);
										nextDay.setDate(nextDay.getDate() + 1);
								    var outDate = nextDay.getFullYear() + '-' + (nextDay.getMonth() + 1) + '-' + nextDay.getDate();
										$.fn.bookingUpdateDepartureDate($(this),outDate);
										$( ".bookFldDate.endDate" ).val(outDate);
										$( ".bookFldDate.endDate" ).datepicker( "option", "minDate", outDate );
									}
								}
						});
						$(".bookFldDate.endDate").datepicker({
								rangeSelect: true,
								dateFormat: 'yy-mm-dd',
								defaultDate: +1,
								minDate: +1,
								onSelect: function( selectedDate ) {
									if ($( ".bookFldDate.startDate" ).length) {
										$.fn.bookingUpdateDepartureDate($(this),selectedDate);
										$( ".bookFldDate.startDate" ).datepicker( "option", "maxDate", selectedDate );
									}
								}
						});
				}
				/* BOOKING PANEL */
				if ($('.btnDropUp').length) {
						$('.btnDropUp').click(function() {
								$('#bookingPanel').hide('slide', { direction: 'up' }, 300);
								$('.btnDropUp').attr('close-act', '1');
						});
				}
				if ($('#bookingButton').length) {
						$('#bookingButton').click(function() { 
								var clickAction = $(this).attr('click-act');
								if (clickAction=="panel") {
									/* BOOKING PANEL */
									if ($('#bookingPanel').is(':visible')) {
											$('#bookingPanel').hide('slide', { direction: 'up' }, 300);
											$('.btnDropUp').attr('close-act', '1');
									} else {
											$('#bookingPanel').show('slide', { direction: 'up' }, 300);
											$('.btnDropUp').attr('close-act', '0');
									}
							    } else {
									/* BOOKING POPUP */
									$.fn.showModalForm($(this));
								}
						});
				}
				
				if ($('.openModal').length) {
						$('.openModal').click(function() {
								$.fn.showModalForm($(this));
						});
				}
				
				$("#fix").click(function() {
				    $(".ui-selectmenu-button").wrap("<div class='ui-selectmenu'></div>");
				    $(".ui-selectmenu-menu").detach().appendTo($(".ui-selectmenu")).css("position", "relative");
				});
				/* QUICK BOOKING TAB */
				if ($('ul.qckBookTabBtn').length) {
						$('ul.qckBookTabBtn>li').click(function() {
								var tabID = $(this).attr('tab-id');
								/* SWITCH TAB BUTTON */
								$('ul.qckBookTabBtn>li.bookTabOn').removeClass('bookTabOn');
								$(this).addClass('bookTabOn');
								/* SWAP TAB CONTENT */
								$('.qckBookFlp').hide();
								$('#'+tabID).fadeIn('fast');
						});
				}
				
				/* MAIN BANNER SLIDER */
				if ($('#mainBannerSlider').length) {
						var eventSlider = $('#mainBannerSlider').bxSlider({
								mode: 'fade',
								auto: true,
							  stopAutoOnClick: true,
							  pager: true,
								captions: false,
								pause: 8000,
						    touchEnabled:false,
								onSliderLoad: function(){
						        if ( !$('.bx-clone').is(":visible") ) {
						            $('.bx-clone').show();
						        }
						    }
						});
				}

				/* BANNER CLICK */
			  	if ($('.bannerClick').length) {
			  		$('.bannerClick').click(function(event) {
			  			event.preventDefault();
			  			var goLink = $(this).data('go-to');
			  			var goType = $(this).data('go-type');
			  			if (goLink!="") {
				  			if (goType=="_blank") {
								window.open(goLink);
						 	} else {
						  		window.location = goLink;
						 	} 
						}
						return false;
			  		});
			  	}
				
				/* FOOTER BANNER */
				if ($('#footerBanner').length && $('#footerBanner > div').length>1) {
						var eventSlider = $('#footerBanner').bxSlider({
								auto: true,
							  stopAutoOnClick: true,
							  pager: false,
								captions: false,
								controls: true,
								pause: 8000,
						    touchEnabled:false,
								onSliderLoad: function(){
						        if ( !$('.bx-clone').is(":visible") ) {
						            $('.bx-clone').show();
						        }
						    }
						});
				}
				
				/* MOBILE SLIDER */
				if ($('.sliderMbl').length) {
					  var scrWidth = $( document ).width();
						$('.sliderMbl').bxSlider({
						    slideWidth: scrWidth-38,
						    minSlides: 1,
						    maxSlides: 3,
						    moveSlides: 1,
						    controls:true,
								startSlide: 0,
							  hideControlOnEnd: true,
							  infiniteLoop: false,
						    pager: true,
						    auto: false,
						    touchEnabled:false
						});
				}
				
				/* OFFERS SLIDERS */
				if ($('.slideOffers').length && $('.slideOffers > div').length>1) {
						var thisSlider = $('.slideOffers').bxSlider({
								mode: 'horizontal',
								auto: false,
							  stopAutoOnClick: true,
							  pager: true,
							  infiniteLoop: false,
								captions: true,
								controls: true,
								startSlide: 0,
							  hideControlOnEnd: true,
								adaptiveHeight: true,
						    touchEnabled:false,
								onSliderLoad: function(){
										$('.slideOffers > div').css("display", "block");
						        if ( !$('.bx-clone').is(":visible") ) {
						            $('.bx-clone').show();
						        }
						    }
						});
				} else {
						$('.slideOffers > div').css("display", "block");
				}
				
				/* EVENT SLIDER */
				if ($('#eventSlide').length) {
						var eventSlider = $('#eventSlide').bxSlider({
								mode: 'horizontal',
								auto: true,
							  stopAutoOnClick: true,
							  pager: true,
								captions: true,
								onSliderLoad: function(){
						        $(".evntSlideClip").css("display", "block");
						        if ( !$('.bx-clone').is(":visible") ) {
						            $('.bx-clone').show();
						        }
						    }
						});
				}
				
				/* DINING SLIDER */
				if ($('.cntSlide').length && $('.cntSlide > img').length>1) {
						var contentSlider = $('.cntSlide').bxSlider({
								mode: 'horizontal',
								auto: true,
							  stopAutoOnClick: true,
							  pager: false,
							  controls: true,
						    touchEnabled:false
						});
				}
				
				/* REVIEWS SLIDER */
				if ($('#reviewSlide').length) {
						var eventSlider = $('#reviewSlide').bxSlider({
								mode: 'fade',
								auto: true,
								autoHover: true,
							  stopAutoOnClick: true,
							  pager: true,
							  controls: true,
								startSlide: 0,
							  hideControlOnEnd: true,
								captions: false,
						    touchEnabled:false
						});
				}
				
				/* ROOM SLIDER */
				if ($('#roomSlide').length) {
						var thumb = $('#roomSlideThumbs').find('div.bxPagerThumbs');
						// Function to calculate which slide to move the thumbs to
					  function slideThumbs(currentSlideNumber, visibleThumbs) {
					
					    // Calculate the first number and ignore the remainder
					    var m = Math.floor(currentSlideNumber / visibleThumbs);
					    // Multiply by the number of visible slides to calculate the exact slide we need to move to
					    var slideTo = m;
					
					    // Tell the slider to move
					    roomSlider.goToSlide(slideTo);
					  }
						var roomSlider = $('#roomSlide').bxSlider({
								mode: 'horizontal',
								auto: false,
							  stopAutoOnClick: true,
							  pager: false,
								captions: true,
						    touchEnabled:false,
						    infiniteLoop: false,
						    startSlide: 0,
							  hideControlOnEnd: false,
								adaptiveHeight: true,
								onSliderLoad: function(){
						        $(".rmSlideClip").css("display", "block");
						        if ( !$('.bx-clone').is(":visible") ) {
						            $('.bx-clone').show();
						        }
						    },
						    onSlideAfter: function ($slideElement, oldIndex, newIndex) {
						      thumb.removeClass('pager-active');
						      thumb.eq(newIndex).addClass('pager-active');
						      // Action next carousel slide on one before the end, so newIndex + 1
						      slideThumbs(newIndex + 1, visibleThumbs);
						    }
						});
						
						if ($('#roomSlideThumbs').length > 0) {
						  // Cache the thumb selector for speed
						
						  // How many thumbs do you want to show & scroll by
						  var visibleThumbs = 15;
						
						  // When clicking a thumb
						  thumb.click(function (e) {
						
						    // -6 as BX slider clones a bunch of elements
						    roomSlider.goToSlide($(this).closest('div.bxPagerThumbs').index());
						
						    // Prevent default click behaviour
						    e.preventDefault();
						  });
						
						  // When you click on a thumb
						  $('#roomSlideThumbs').find('div.bxPagerThumbs').click(function () {
						
						    // Remove the active class from all thumbs
						    $('#roomSlideThumbs').find('div.bxPagerThumbs').removeClass('pager-active');
						
						    // Add the active class to the clicked thumb
						    $(this).addClass('pager-active');
						
						  });
						
						  // Thumbnail slider
						  /*var thumbsSlider = $('#roomSlideThumbs').bxSlider({
						    controls: false,
						    pager: false,
						    easing: 'easeInOutQuint',
						    //displaySlideQty: visibleThumbs,
						    //moveSlideQty: visibleThumbs,
						    infiniteLoop: false,
						    slideWidth: 100,
						    minSlides: visibleThumbs,
						    maxSlides: visibleThumbs,
						    slideMargin: 10
						  });*/
						
						}
				}
				
				/* FACILITY SLIDER */
				if ($('#facilitySlide').length) {
						var facilityLnk = $('ul.fcltNv').find('li');
						function slideFacilityLnk(currentSlideNumber, visibleLnk) {
					
					    // Calculate the first number and ignore the remainder
					    var lnk = Math.floor(currentSlideNumber / visibleLnk);
					    // Multiply by the number of visible slides to calculate the exact slide we need to move to
					    var slideToLnk = currentSlideNumber;
							
					    // Tell the slider to move
					    facilitySlider.goToSlide(slideToLnk);
					  }
						var facilitySlider = $('#facilitySlide').bxSlider({
								mode: 'horizontal',
								auto: false,
							  stopAutoOnClick: true,
							  pager: true,
								captions: true,
								startSlide: 0,
							  hideControlOnEnd: true,
								onSliderLoad: function(){
						        $(".fcltSlideClip").css("display", "block");
						        if ( !$('.bx-clone').is(":visible") ) {
						            $('.bx-clone').show();
						        }
						    },
						    onSlideAfter: function ($slideElement, oldLnkIndex, newLnkIndex) {
						      facilityLnk.removeClass('fcltOn');
					      	facilityLnk.eq(newLnkIndex).addClass('fcltOn');
					      	// Action next carousel slide on one before the end, so newLnkIndex + 1
					      	slideFacilityLnk(newLnkIndex, visibleLnk);
						    }
						});
						if ($('ul.fcltNv').length > 0) {
						  // Cache the thumb selector for speed
						
						  // How many thumbs do you want to show & scroll by
						  var visibleLnk = 15;
						
						  // When clicking a thumb
						  facilityLnk.click(function (e) {
						
						    // -6 as BX slider clones a bunch of elements
						    facilitySlider.goToSlide($(this).closest('li').index());
						
						    // Prevent default click behaviour
						    e.preventDefault();
						  });
						
						  // When you click on a thumb
						  $('ul.fcltNv').find('li').click(function () {
						
						    // Remove the active class from all thumbs
						    $('ul.fcltNv').find('li').removeClass('fcltOn');
						
						    // Add the active class to the clicked thumb
						    $(this).addClass('fcltOn');
						
						  });
						}
						
						if ($('ul.fcltNv').length && $('ul.fcltNv > li').length>0) {
								/*$('ul.fcltNv > li').click(function() {
										$('ul.fcltNv > li.fcltOn').removeClass('fcltOn');
										$(this).addClass('fcltOn');
										var slideNum = $(this).attr('sld-num');
										facilitySlider.goToSlide(slideNum);
								});*/
						}
				}
				
				/* ARTICLE SLIDER */
				if ($('.slideArticles').length && $('.slideArticles > div').length>1) {
						var thisSlider = $('.slideArticles').bxSlider({
								mode: 'horizontal',
								auto: false,
							  stopAutoOnClick: true,
							  pager: true,
								captions: true,
								startSlide: 0,
							  hideControlOnEnd: true,
							  infiniteLoop: false,
								controls: true,
								adaptiveHeight: true,
								onSliderLoad: function(){
										$('.slideArticles > div').css("display", "block");
						        if ( !$('.bx-clone').is(":visible") ) {
						            $('.bx-clone').show();
						        }
						    }
						});
				} else {
						$('.slideArticles > div').css("display", "block");
				}
				
				/* ROOM DETAILS TAB */
				if ($('ul.roomTabLink>li').length) {
						$('ul.roomTabLink>li').click(function() {
								var tagContentID = $(this).attr('data-tag');
								var clickObj = $(this);
								if (!$('#'+tagContentID).is(':visible')) {
										$('.roomContentBox').hide(200, function() {
											$('ul.roomTabLink>li').removeClass('tabOn');
											$('#'+tagContentID).show(200);
											clickObj.addClass('tabOn');
										});
								}
						});
				}
				/* ---------------- */
				
				/* LOCATION LINK HOME PAGE */
				if ($('.locLnkInfoBox').length) {
						if (!isMobile) {
								$('.locLnkInfoBox').hoverIntent(
									  function() {
									  	 $(this).find('.locLnkFold').fadeIn(200);
									  }, function() {
									  	 $(this).find('.locLnkFold').fadeOut(100);
									  }
								);
						}
				}
				
				/* FANCY BOX */
				if ($(".fancyLnk").length) {
						$(".fancyLnk").fancybox();
				}
				if ($(".fancyAjxLnk").length) {
						$('.fancyAjxLnk').on('click', function() {
								var ajxUrl = $(this).attr("data-url");
						    $('#bioBox').load(ajxUrl, function(){
						       $.fancybox();
						    });
						    /*$.fancybox.open({
						        href: ajxUrl,
						        type: "ajax",
						        ajax: {
						            type: "POST",
						            data: {
						                temp: "tada"
						            }
						        }
						    });*/
						});
				}
				/* --------- */
				
				/* PHOTO GROUP */
				if ($(".photoGroupLnk").length) {
						$(".photoGroupLnk").click(function() {
								$(this).addClass("groupLnkOn");
								$(".photoGroupLnk").not(this).removeClass("groupLnkOn");
								var groupID = $(this).attr("group-id");
								if (groupID=="all") {
									/*$(".photoBox").each(function(i) {
									    $(this).delay(100 * i).fadeIn("slow");
									});*/
									$(".photoFrame").fadeIn();
								} else {
									var groupObj = $(".photoFrame[group-type='" + groupID + "']");
									var hideGroupObj = $(".photoFrame[group-type!='" + groupID + "']");
									//var elems = hideGroupObj.nextAll()
									var count = groupObj.length-1;
									if (groupObj.length==0) {
										/*$(".photoBox").each(function(i) {
										    $(this).delay(100 * i).fadeOut("slow");
										});*/
										$(".photoFrame").fadeOut();
									} else {
										if (!groupObj.is(':visible')) {
											/*groupObj.each(function(i) {
													$(this).delay(100 * i).fadeIn("slow");
													if (i==count) { hideGroupObj.fadeOut("fast"); }
											});*/
											hideGroupObj.fadeOut("fast", function() {
												groupObj.fadeIn();
											});
										} else {
											/*hideGroupObj.each(function(i) {
													$(this).delay(50 * i).fadeOut("fast");
											});*/
											hideGroupObj.fadeOut("fast");
										}
									}
								}
						});
				}
				if ($("select.photoGroupSel").length) {
						$("select.photoGroupSel").on("change", function() {
							  var groupID = this.value;
							  if (groupID=="all") {
										$(".photoFrame").fadeIn();
								} else {
										var groupObj = $(".photoFrame[group-type='" + groupID + "']");
										var hideGroupObj = $(".photoFrame[group-type!='" + groupID + "']");
										var count = groupObj.length-1;
										if (groupObj.length==0) {
											$(".photoFrame").fadeOut();
										} else {
											if (!groupObj.is(':visible')) {
												hideGroupObj.fadeOut("fast", function() {
													groupObj.fadeIn();
												});
											} else {
												hideGroupObj.fadeOut("fast");
											}
										}
								}
						});
				}
				if ($(".photoBox").length) {
						$(".photoBox").fancybox();
						$(".photoBox").hoverIntent(
							  function() {
							     $(this).find('.photoTitle').fadeIn(300);
							  }, function() {
							     $(this).find('.photoTitle').fadeOut(300);
							  }
						);
				}
				if ($(".photoFancy").length) {
						$(".photoFancy").fancybox();
				}
				
				/* BOOK MODAL */
				if ($('.btnBookMdlClose').length) {
						$('.btnBookMdlClose').click(function() {
								$.fn.closeModalForm($('.btnBookMdlClose'));
						});
				}
				
				/* MASONRY DISPLAY */
				if ($("#aboutHomeTile").length) {
						$("#aboutHomeTile").masonry();
				}
				
				/* FILTER LOCATION CAREER LIST */
				if ($(".doFilter").length) {
						$(".doFilter").on('selectmenuchange', function() {
								var locID = $(this).val();
								var loadingObj = $('.careerLoading');
								var urlType = $(this).attr("data-type");
								var previewID = $(this).attr("data-preview");
						    $.ajax({
										method: "GET",
									  url: "./inc/ajx-parse/reload-"+urlType+".php",
									  data: { ajxDo:"reloadListWithFilter", locID:locID },
									  cache: false,
									  beforeSend: function( xhr ) {
									   		loadingObj.fadeIn();
									  }
								}).done(function( returnText ) {
										if (returnText!="") {
												$('#'+previewID).html(returnText);
												loadingObj.fadeOut('fast');
										}
								}); 
						});
				}
				
				/* WA SERVICE POP */
				if ($("a.lnkOpacity").length) {
						$("a.lnkOpacity").click(function() {
								if ($("#waServModal").is(":visible")) {
										$("#waServModal").hide('slide', { direction: 'right' }, 300);
								} else {
										$("#waServModal").show('slide', { direction: 'right' }, 300);
								}
						});
				}
				if ($("a.waServClose").length) {
						$("a.waServClose").click(function() {
								$("#waServModal").hide('slide', { direction: 'right' }, 300);
						});
				}
				
				/* PASSWORD METER */
	    		if ($('.fldPasswd').length) {
			  		$('.fldPasswd').password();
				}
				/* -------------- */

				if ($(".mdlBox").length) {
					if ($('.modalAuto').length) {
		    			var CurrentDate = new Date();
		    			var popDtStart = new Date($('.modalAuto').attr('data-start'));
		    			var popDtEnd = new Date($('.modalAuto').attr('data-end'));
		    			var countDown = $('.modalAuto').data("countdown");
		    			if (popDtStart<=CurrentDate && popDtEnd>=CurrentDate) {
		    			    if (countDown!="") {
		    			        $.fn.initializeCountDown(countDown);
		    			    }
		    				$.fn.showModalPop($('.modalAuto'));
		    			}
						/* SCROLLED WINDOW, CLOSE */
						$(window).scroll(function(event) {
							if ($('.modalAuto').is(':visible')) {
								$.fn.closeModalPop($('.modalAuto'));
							}
						});
			    		$(document).mouseup(function(e) {
						    var container = $('.modalAuto');
							if (!container.is(e.target) && container.has(e.target).length === 0 && container.is(':visible')) {
						        $.fn.closeModalPop(container);
						    }
						});
		    		}

		    		if ($("a.btnMdlClose").length) {
		    			$("a.btnMdlClose").click(function() {
		    				var mdlBox = $(this).parents(".mdlBox");
		    				$.fn.closeModalPop(mdlBox);
		    			});
		    		}
				}
				
				/* FORM ALERT CLOSE */
    			$("body").on("click",".frmAlertClose",function() {
    					var alertBox = $(this).parents(".frmAlert");
    					var alertMsg = alertBox.find(".frmAlertCnt");
    					$.fn.closeAlert(alertBox,alertMsg);
    			});

				if ($("form#formBooking").length) {
					$("form#formBooking").ajaxForm({ 
					 	target: '#formTarget', 
				 		beforeSubmit:function() {
			 				$.fn.trimThisField($("input[type=text]"));
			 				$('#formButton').prop("disabled", true);
	 						$("#formAlert").hide();
	 						$('.frmAlertCnt').html("");
			            	$('#formLoading').fadeIn('slow');
				        },
				        success: function() { 
			        		$('#formLoading').fadeOut('fast', function() {
			        			var str = $('#formTarget').html();
			        			var arrStr = str.split("[|]");
			        			if (arrStr[0]=="success") {
			        				$('#formAlert').html("<div class=\"alertDone\">"+arrStr[1]+"</div>");
			        			} else if (arrStr[0]=="refresh") {
			        				location.reload(true);
    		        			} else if (arrStr[0]=="show-text") {
    		        			    $('#formContent').fadeOut(function(){
    		        			        $('#formContent').html(arrStr[1]);
    		        			        $('#formContent').fadeIn();
    		        			    });
			        			} else if (arrStr[0]=="go-link") {
			        				goURL(arrStr[1]);
			        			} else {
				        			$('.frmAlertCnt').html(arrStr[1]);
				        			$("#formAlert").show(300);
				        			$('html, body').stop().animate({scrollTop: $("#formAlert").offset().top-200}, 900, 'swing');
				        		}
				        		$(".bookMdlArea").stop().animate({scrollTop: 0}, 900, 'swing');
				        		$('#formButton').prop("disabled", false);
			        		});
				        } 
					});
				   	$('#formButton').prop("disabled", false);
				}
				
				if ($("form#formMembership").length) {
				    $("form#formMembership").ajaxForm({ 
					 	target: '#formTarget', 
				 		beforeSubmit:function() {
			 				$.fn.trimThisField($("input[type=text]"));
			 				$('#formMembership').find("input[type=submit]").prop("disabled", true);
	 						$("#formAlert").hide();
	 						$('.frmAlertCnt').html("");
			            	$('#formLoading').fadeIn('slow');
				        },
				        success: function() { 
			        		$('#formLoading').fadeOut('fast', function() {
			        			var str = $('#formTarget').html();
			        			var arrStr = str.split("[|]");
			        			if (arrStr[0]=="success") {
			        				$('#formAlert').html("<div class=\"alertDone\">"+arrStr[1]+"</div>");
			        			} else if (arrStr[0]=="refresh") {
			        				location.reload(true);
    		        			} else if (arrStr[0]=="show-text") {
    		        			    $('#formContent').fadeOut(function(){
    		        			        $('#formContent').html(arrStr[1]);
    		        			        $('#formContent').fadeIn();
    		        			    });
			        			} else if (arrStr[0]=="go-link") {
			        				goURL(arrStr[1]);
			        			} else {
				        			$('.frmAlertCnt').html(arrStr[1]);
				        			$("#formAlert").show(300);
				        			$('html, body').stop().animate({scrollTop: $("#formAlert").offset().top-200}, 900, 'swing');
				        		}
				        		$(".bookMdlArea").stop().animate({scrollTop: 0}, 900, 'swing');
				        		$('#formMembership').find("input[type=submit]").prop("disabled", false);
			        		});
				        } 
					});
				   	$('#formMembership').find("input[type=submit]").prop("disabled", false);
				}
				
				if ($(".compFld").length) {
				    $(".compFld").change(function() {
				        var thisVal = $(this).val();
				        if (thisVal=="Yes") {
				            $(".compAnsw").show();
				        } else {
				            $(".compAnsw").hide();
				        }
				    });
				}
				
				/* DROP MENU */
				if ($('ul.nvMenu, ul.nvIcon').length) {
					if (!isMobile) {
						/* NAVIGATION DROP DOWN DESKTOP */
						$('li.wDrop').hoverIntent(
							function() {
								$(this).children('.nvDrop').slideDown('fast');
							}, function() {
							  	$(this).children('.nvDrop').slideUp('fast');
							}
						);
					} else {
						/* NAVIGATION DROP DOWN MOBILE */
						$('li.wDrop').click(function() {
							var clickObj = $(this);
							var dropMenu = $(this).find('.nvDrop');
							var levelSibling = $(this).siblings('li.wDrop');
							if ( !dropMenu.is(":visible") ) {
								levelSibling.children('.nvDrop:visible').fadeOut();
								dropMenu.fadeIn();
							} else {
								dropMenu.fadeOut();
							}
						});
						/* navigation Menu bottom */
						if ($(".btmNvBx").length) {
							$(".btmNvBx").click(function() {
								var clickObj = $(this);
								var dropMenu = $(this).find('ul.nvBtm');
								if ( !dropMenu.is(":visible") ) {
									$('ul.nvBtm:visible').slideUp();
									dropMenu.slideDown();
								} else {
									dropMenu.slideUp();
								}
							});
						}
					}
				}
				
				if ($(".showPopup").length) {
				    $(".showPopup").click(function() {
				        var dataModal = $(this).data("modalbox");
				        $.fn.showModalPop($('.'+dataModal));
				    });
				    
				}
				
				/* OTP VERIFICATION */
				if ($(".verifyMe").length) {
				    $(".verifyMe").click(function() {
				        /* 01. GENERATE & SEND OTP */
				        var actWay = $(this).data("how");
				        var actCode = $(this).data("to");
				        var actLang = $(this).data("lang");
				        $.ajax({
							  method: "POST",
							  url: "./send-otp",
							  data: { ajxDo:"requestNewOTP", actWay:actWay, actCode:actCode, actLang:actLang },
							  cache: false,
							  beforeSend: function( xhr ) {
							   		loadingObj.fadeIn();
							  }
						}).done(function( returnText ) {
								if (returnText!="") {
										$('#'+previewID).html(returnText);
										loadingObj.fadeOut('fast');
								}
						}); 
				    });
				}
				
				/* edit profile */
				if ($(".editArea").length) {
				    /* edit button */
				    $(".editThis").click(function() {
				        $.fn.showEditFields($(this).siblings(".edtDisplay"));
				    });
				    /* cancel edit button */
				    $(".cancelEdit").click(function() {
				        $.fn.hideEditFields($(this).siblings(".edtDisplay"));
				    });
				}
		});
});
//-->